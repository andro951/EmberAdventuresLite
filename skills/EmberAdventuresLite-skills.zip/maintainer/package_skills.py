"""Build complete, reproducible skill archives; public repositories contain ZIPs only."""
import argparse
import hashlib
import json
import pathlib
import re
import shutil
import subprocess
import zipfile

PRODUCTS = {
    "normal": ("EmberAdventures", ["emberadventures-character", "emberadventures-story"]),
    "lite": ("EmberAdventuresLite", ["emberadventureslite-character", "emberadventureslite-story"]),
}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def package(source, product, names, script):
    files = {}
    versions = {}
    for name in names:
        folder = source / name
        if not (folder / "SKILL.md").is_file():
            raise ValueError(f"Missing skill: {folder}")
        text = (folder / "SKILL.md").read_text(encoding="utf-8-sig")
        version = re.search(r"(?:Current skill version: `|Version: )(\d+\.\d+\.\d+)", text)
        if not version:
            raise ValueError(f"Missing version: {name}")
        versions[name] = version.group(1)
        for file in sorted(folder.rglob("*")):
            if not file.is_file():
                continue
            relative = file.relative_to(folder)
            if any(part.startswith(".") or part in {"__pycache__", "node_modules", "private-data", "test-output"} for part in relative.parts):
                raise ValueError(f"Do not package private/cache files: {file}")
            if file.suffix not in {".md", ".json", ".yaml", ".cjs"}:
                raise ValueError(f"Unexpected resource: {file}")
            files[f"{name}/{relative.as_posix()}"] = file.read_bytes()
    files["maintainer/package_skills.py"] = script.read_bytes()
    readme = f"""# {product} authoring skills\n\nExtract this archive before use. Install the two named skill folders into your\nCodex skills directory, or provide their instructions and required references\nto an assistant as ordinary files. Start with each SKILL.md and follow its links.\nFor stories, load both character and story skills.\n\nThe references include full JSON examples and canonical field snapshots.\nThe optional character scripts/validate-content.cjs helper accepts the matching\nlocal game checkout and one or more exported JSON files; it never repairs them.\nThe archive is not a game build and contains no personal preferences.\n\nPublic distribution is ZIP-only. After skill maintenance, validate resources,\nupdate installed copies, rebuild using maintainer/package_skills.py, replace the\nmatching archive under downloads/ in ember-adventures-tools and skills/ in the\ngame repository, then push. Do not publish extracted folders or version files.\nFor a single extracted bundle, use --source <extracted-root> --kind {'lite' if product.endswith('Lite') else 'normal'}.\nUse --help for explicit source, destination and optional validation/install paths.\n\nVersions:\n""" + "".join(f"- {name}: {versions[name]}\n" for name in names)
    files["README.md"] = readme.rstrip().encode()
    manifest = {"product": product, "skills": versions, "files": {name:digest(data) for name,data in sorted(files.items())}}
    files["manifest.json"] = json.dumps(manifest, indent=2, ensure_ascii=False).encode()
    return files

def write_zip(file, files):
    file.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(file, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(files.items()):
            entry = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, data, compresslevel=9)
    with zipfile.ZipFile(file) as archive:
        if archive.testzip() is not None or set(archive.namelist()) != set(files):
            raise ValueError(f"ZIP verification failed: {file}")
        for name,data in files.items():
            if archive.read(name) != data:
                raise ValueError(f"ZIP entry mismatch: {name}")

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=pathlib.Path, required=True)
    parser.add_argument("--public", type=pathlib.Path, required=True, help="Public ember-adventures-tools checkout")
    parser.add_argument("--kind", choices=["normal", "lite", "all"], default="all")
    parser.add_argument("--normal-repo", type=pathlib.Path)
    parser.add_argument("--lite-repo", type=pathlib.Path)
    parser.add_argument("--install-root", type=pathlib.Path)
    parser.add_argument("--node", default="node")
    args = parser.parse_args()
    if (args.public.resolve() / ".git").exists():
        tracked = subprocess.run(["git", "ls-files"], cwd=args.public, check=True, capture_output=True, text=True).stdout.splitlines()
        if any(not name.endswith(".zip") for name in tracked):
            raise ValueError("The public skill repository must track ZIP files only. Preserve editable sources locally before removing loose published files.")
    source = args.source.resolve()
    if (source / "skills").is_dir():
        source /= "skills"
    selected = list(PRODUCTS) if args.kind == "all" else [args.kind]
    for kind in selected:
        product,names = PRODUCTS[kind]
        repo = args.lite_repo if kind == "lite" else args.normal_repo
        if repo:
            subprocess.run([args.node, str(source/names[0]/"scripts/validate-content.cjs"), str(repo.resolve()),
                            str(source/names[0]/"references/reference-character.json"), str(source/names[1]/"references/reference-story.json")],check=True)
        files = package(source,product,names,pathlib.Path(__file__).resolve())
        output = args.public.resolve()/"downloads"/(product+"-skills.zip")
        write_zip(output,files)
        if repo:
            destination=repo.resolve()/"skills"/output.name
            destination.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(output,destination)
        if args.install_root:
            for name in names:
                destination=args.install_root.resolve()/name
                if destination != (source/name).resolve():
                    shutil.copytree(source/name,destination,dirs_exist_ok=True)
        print(f"Packaged {product}: {len(files)} files; SHA-256 {digest(output.read_bytes())}")

if __name__ == "__main__":
    main()